package marketStoreSystem;

public class Tier {
    Bronze bronze;
    Silver silver;
    Gold gold;

}
