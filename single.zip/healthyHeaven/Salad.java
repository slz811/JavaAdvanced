package healthyHeaven;

import java.util.LinkedHashSet;
import java.util.Set;

public class Salad {
    private String name;
    private Set<Vegetable> products;
    private int calories;

    public Salad(String name) {
        this.name = name;
        this.products = new LinkedHashSet<>();
        this.calories = 0;
    }

    public String getName() {
        return name;
    }

    public int getProductCount() {
        return this.products.size();
    }

    public int getTotalCalories() {
        int totalCalories = 0;
        for (Vegetable product : this.products) {
            totalCalories += product.getCalories();
        }
        this.calories = totalCalories;
        return this.calories;
    }

    public void add(Vegetable vegetable) {
        this.products.add(vegetable);
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("* Salad %s is %d calories and have %d products:%n",
                getName(), getTotalCalories(), getProductCount()));
        this.products.forEach(vegetable -> sb.append(vegetable.toString()));
        //sb.append(System.getProperty("line.separator"));
        return sb.toString().trim();
    }
}
