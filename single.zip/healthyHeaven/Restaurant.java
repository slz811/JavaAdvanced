package healthyHeaven;

import java.util.LinkedHashSet;
import java.util.Set;

public class Restaurant {
    private String name;
    private Set<Salad> data;

    public Restaurant(String name) {
        this.name = name;
        this.data = new LinkedHashSet<>();
    }

    public String getName() {
        return this.name;
    }

    public int getSaladCounts() {
        return this.data.size();
    }

    public void add(Salad salad) {
        this.data.add(salad);
    }

    public boolean buy(String saladName) {
        Salad toRemove = null;
        for (Salad salad : this.data) {
            if (salad.getName().equals(saladName)) {
                toRemove = salad;
                break;
            }
        }
        return this.data.remove(toRemove);
    }

    public String getHealthiestSalad() {
        String theHealthiestSalad = "";
        int cal = Integer.MAX_VALUE;
        for (Salad salad : this.data) {
            if (salad.getTotalCalories() < cal) {
                cal = salad.getTotalCalories();
                theHealthiestSalad = salad.getName();
            }
        }
        return theHealthiestSalad;
    }
//"{name} have {salad count} salads:
//{Salad 1}
//{Salad 2}

    public String generateMenu() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s have %d salads:%n", getName(), getSaladCounts()));
        this.data.forEach(salad -> sb.append(salad.toString()));
        return sb.toString().trim();
    }
}
